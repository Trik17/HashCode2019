public class SubMatrix {

    public int col1, row1, col2, row2, dimcol, dimrow;


    public SubMatrix(int col1, int row1, int col2, int row2, int dimcol, int dimrow) {
        this.col1 = col1;
        this.row1 = row1;
        this.col2 = col2;
        this.row2 = row2;
        this.dimcol = dimcol;
        this.dimrow = dimrow;
    }
}
